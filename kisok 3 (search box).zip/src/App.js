import React, { useState, useEffect } from "react";
import axios from "axios";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import { Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import { FaShoppingCart } from "react-icons/fa";

import ProductList from "./components/ProductList/ProductList";
import CartModal from "./components/CartModal/CartModal";
import ProductDetailModal from "./components/ProductDetail/ProductDetailModal";
import Footer from "./components/Footer/Footer";
import UserOrderHistory from "./components/UserOrderHistory/UserOrderHistory";

import {
  Toast,
  Form,
  InputGroup,
  Container,
  Modal,
  Button,
} from "react-bootstrap";

const App = () => {
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState([]);
  const [showCartModal, setShowCartModal] = useState(false);
  const [showAdmissionModal, setShowAdmissionModal] = useState(false);
  const [admissionNumber, setAdmissionNumber] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [showProductDetailModal, setShowProductDetailModal] = useState(false);
  const [showOrderHistory, setShowOrderHistory] = useState(false);
  const [showCheckoutToast, setShowCheckoutToast] = useState(false);
  const [showReceiptModal, setShowReceiptModal] = useState(false);
  const [checkoutError, setCheckoutError] = useState("");
  const [suggestedItems, setSuggestedItems] = useState([]);
  const [searchFocused, setSearchFocused] = useState(false);
  const [highlightedIndex, setHighlightedIndex] = useState(-1);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await axios.get("/api/products");
        setProducts(response.data);
      } catch (error) {
        console.error("Error fetching products:", error);
      }
    };
    fetchProducts();
  }, []);

  const addToCart = async (productId) => {
    try {
      const { data: product } = await axios.get(`/api/products/${productId}`);
      if (!product || product.quantity <= 0) return;
      setCart((prev) => {
        const exists = prev.find((p) => p._id === product._id);
        if (exists) {
          return prev.map((p) =>
            p._id === product._id ? { ...p, quantity: p.quantity + 1 } : p
          );
        }
        return [...prev, { ...product, quantity: 1 }];
      });
      await axios.post("/api/products/update-quantity", {
        id: product._id,
        quantityChange: -1,
      });
      setShowCartModal(true);
    } catch (err) {
      console.error(err);
      alert("Failed to add product to cart.");
    }
  };

  const incrementQuantity = (productId) =>
    setCart((prev) =>
      prev.map((p) =>
        p._id === productId ? { ...p, quantity: p.quantity + 1 } : p
      )
    );

  const decrementQuantity = (productId) =>
    setCart((prev) =>
      prev.map((p) =>
        p._id === productId && p.quantity > 1
          ? { ...p, quantity: p.quantity - 1 }
          : p
      )
    );

  const removeFromCart = (prod) =>
    setCart((prev) => prev.filter((p) => p._id !== prod._id));

  const clearCart = () => setCart([]);

  const calculateTotal = () =>
    cart.reduce((sum, p) => sum + p.price * p.quantity, 0);

  const checkout = () => {
    setShowCartModal(false);
    setShowAdmissionModal(true);
  };

  // Fetch and analyze user order history for suggestions
  const fetchUserSuggestions = async (adNo) => {
    try {
      const response = await axios.get("/api/sales");
      const userOrders = response.data.filter((order) => order.userId === adNo);
      // Count item purchases
      const itemCounts = {};
      userOrders.forEach((order) => {
        order.items.forEach((item) => {
          if (!itemCounts[item.id]) itemCounts[item.id] = { ...item, count: 0 };
          itemCounts[item.id].count += item.quantity;
        });
      });
      // Merge image from products list
      const merged = Object.values(itemCounts).map((item) => {
        const prod = products.find((p) => p._id === item.id || p.id === item.id);
        return {
          ...item,
          image: prod ? prod.image : "https://via.placeholder.com/36?text=No+Img"
        };
      });
      // Sort by most purchased
      const sorted = merged.sort((a, b) => b.count - a.count);
      setSuggestedItems(sorted.slice(0, 5)); // Top 5 suggestions
    } catch (err) {
      setSuggestedItems([]);
    }
  };

  const handleAdmissionConfirm = async () => {
    if (!admissionNumber) {
      setCheckoutError("Please enter your admission number.");
      return;
    }
    setShowAdmissionModal(false);
    setCheckoutError("");
    // Fetch suggestions for this user
    fetchUserSuggestions(admissionNumber);
    // Prepare sale data
    const saleData = {
      userId: admissionNumber,
      items: cart.map((i) => ({
        id: i._id,
        name: i.name,
        quantity: i.quantity,
        price: i.price,
      })),
      total: calculateTotal(),
      timestamp: Date.now(),
    };
    try {
      await axios.post("/api/sales", saleData);
      // Build PDF
      if (cart.length > 0) {
        const doc = new jsPDF();
        doc.setFontSize(18);
        doc.text("Kiosk Vending Machine Invoice", 14, 22);
        doc.setFontSize(12);
        doc.text(`Date: ${new Date().toLocaleDateString()}`, 14, 30);
        doc.text(`Admission Number: ${admissionNumber}`, 14, 36);
        const columns = ["Item", "Qty", "Price", "Subtotal"];
        const rows = cart.map((item) => [
          item.name,
          item.quantity.toString(),
          `Rs: ${Number(item.price).toFixed(2)}`,
          `Rs: ${(Number(item.price) * item.quantity).toFixed(2)}`,
        ]);
        autoTable(doc, {
          head: [columns],
          body: rows,
          startY: 45,
        });
        const finalY = doc.lastAutoTable ? doc.lastAutoTable.finalY : 45;
        doc.setFontSize(14);
        doc.text(
          `Total Amount\nRs: ${calculateTotal().toFixed(2)}`,
          14,
          finalY + 10
        );
        doc.save(`invoice_${Date.now()}.pdf`);
      }
      clearCart();
      setShowReceiptModal(true);
      setShowCheckoutToast(true);
      setTimeout(() => setShowCheckoutToast(false), 3000);
      // Refetch products to update quantities after purchase
      try {
        const response = await axios.get("/api/products");
        setProducts(response.data);
      } catch (error) {
        console.error("Error fetching products after purchase:", error);
      }
    } catch (err) {
      console.error("Checkout failed:", err);
      setCheckoutError("Checkout failed. Please try again.");
    }
  };

  const handleProductClick = (p) => {
    setSelectedProduct(p);
    setShowProductDetailModal(true);
  };

  const handleHomeClick = () => setShowOrderHistory(false);

  const filtered = products.filter((p) =>
    p.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Floating cart button handler
  const handleFloatingCartClick = () => setShowCartModal(true);

  // Helper to highlight matching text
  function highlightMatch(text, query) {
    if (!query) return text;
    const idx = text.toLowerCase().indexOf(query.toLowerCase());
    if (idx === -1) return text;
    return (
      <>
        {text.substring(0, idx)}
        <span style={{ background: '#ffecd2', color: '#ff6a88', fontWeight: 'bold' }}>{text.substring(idx, idx + query.length)}</span>
        {text.substring(idx + query.length)}
      </>
    );
  }

  return (
    <div className="d-flex flex-column min-vh-100">
      <Container className="d-flex flex-column align-items-center my-3 py-3">
        <div
          className="d-flex align-items-center w-100 mb-2"
          style={{ gap: "1.2rem" }}
        >
          <img
            src={process.env.PUBLIC_URL + "/mepco-logo.png"}
            alt="Mepco College Logo"
            style={{
              height: 64,
              width: "auto",
              borderRadius: "1rem",
              boxShadow: "0 2px 12px #ff6a8855",
            }}
          />
          <h1
            className="fw-bold mb-0"
            style={{ fontSize: "2.2rem", letterSpacing: "0.08em" }}
          >
            <Link
              to="/"
              className="text-decoration-none text-dark App-link"
              onClick={handleHomeClick}
            >
              Kiosk Vending Machine
            </Link>
          </h1>
        </div>
        <div className="d-flex justify-content-center">
          <button onClick={handleHomeClick} className="btn btn-link text-dark">
            Home
          </button>
          <button
            onClick={() => setShowOrderHistory(true)}
            className="btn btn-link text-dark"
          >
            My Orders
          </button>
        </div>
      </Container>
      <Container className="mt-5 flex-grow-1">
        {checkoutError && (
          <Toast
            show
            bg="danger"
            className="position-fixed top-0 end-0 m-3"
            onClose={() => setCheckoutError("")}
          >
            <Toast.Body>{checkoutError}</Toast.Body>
          </Toast>
        )}
        {showOrderHistory ? (
          <UserOrderHistory />
        ) : (
          <>
            <div className="d-flex justify-content-between align-items-center mb-4 row">
              <h1 className="fw-bold col">Today's Items</h1>
              <Form.Group className="w-100 w-md-50 my-auto col" style={{ position: "relative" }}>
                <InputGroup>
                  <InputGroup.Text>
                    <i className="fas fa-search" />
                  </InputGroup.Text>
                  <Form.Control
                    placeholder="Search products..."
                    value={searchTerm}
                    onChange={(e) => {
                      setSearchTerm(e.target.value);
                      setHighlightedIndex(-1);
                    }}
                    onFocus={() => setSearchFocused(true)}
                    onBlur={() => setTimeout(() => setSearchFocused(false), 150)}
                    onKeyDown={(e) => {
                      if (!searchFocused) return;
                      // Filtered suggestions
                      const filteredSuggestions = searchTerm.trim()
                        ? suggestedItems.filter(item => item.name.toLowerCase().includes(searchTerm.toLowerCase()))
                        : suggestedItems;
                      if (filteredSuggestions.length === 0) return;
                      if (e.key === 'ArrowDown') {
                        setHighlightedIndex((prev) => (prev + 1) % filteredSuggestions.length);
                        e.preventDefault();
                      } else if (e.key === 'ArrowUp') {
                        setHighlightedIndex((prev) => (prev - 1 + filteredSuggestions.length) % filteredSuggestions.length);
                        e.preventDefault();
                      } else if (e.key === 'Enter' && highlightedIndex >= 0) {
                        setSearchTerm(filteredSuggestions[highlightedIndex].name);
                        setHighlightedIndex(-1);
                        setSearchFocused(false);
                        e.preventDefault();
                      }
                    }}
                    autoComplete="off"
                  />
                </InputGroup>
                {searchFocused && suggestedItems.length > 0 && (
                  (() => {
                    const filteredSuggestions = searchTerm.trim()
                      ? suggestedItems.filter(item => item.name.toLowerCase().includes(searchTerm.toLowerCase()))
                      : suggestedItems;
                    if (filteredSuggestions.length === 0) return null;
                    return (
                      <div
                        style={{
                          position: "absolute",
                          top: "100%",
                          left: 0,
                          right: 0,
                          background: "#fff",
                          borderRadius: "0 0 1rem 1rem",
                          boxShadow: "0 4px 16px #ff6a8855",
                          zIndex: 10,
                          padding: "0.5rem 0",
                        }}
                      >
                        <div style={{ padding: "0.5rem 1rem", color: "#ff6a88", fontWeight: "bold" }}>
                          Suggestions for you
                        </div>
                        {filteredSuggestions.map((item, idx) => (
                          <div
                            key={item.id}
                            style={{
                              display: 'flex',
                              alignItems: 'center',
                              gap: '0.7rem',
                              padding: "0.5rem 1rem",
                              cursor: "pointer",
                              fontWeight: "bold",
                              color: highlightedIndex === idx ? '#fff' : '#232526',
                              background: highlightedIndex === idx ? '#ff6a88' : 'transparent',
                              borderBottom: "1px solid #ffecd2",
                              borderRadius: highlightedIndex === idx ? 8 : 0,
                              transition: 'background 0.15s, color 0.15s',
                            }}
                            onMouseDown={() => setSearchTerm(item.name)}
                            onMouseEnter={() => setHighlightedIndex(idx)}
                          >
                            <img src={item.image} alt={item.name} style={{ width: 36, height: 36, objectFit: 'cover', borderRadius: 8, boxShadow: '0 2px 8px #ff6a8833' }} />
                            <span style={{ flex: 1 }}>{highlightMatch(item.name, searchTerm)}</span>
                            <span style={{ color: highlightedIndex === idx ? '#fff' : '#ff6a88', fontWeight: "normal", fontSize: "0.95em" }}>({item.count}x)</span>
                          </div>
                        ))}
                      </div>
                    );
                  })()
                )}
              </Form.Group>
            </div>
            {filtered.length > 0 ? (
              <ProductList
                products={filtered}
                addToCart={addToCart}
                onProductClick={handleProductClick}
              />
            ) : (
              <div className="text-center mt-5">
                <h3>No products available.</h3>
              </div>
            )}
            <CartModal
              show={showCartModal}
              handleClose={() => setShowCartModal(false)}
              cart={cart}
              incrementQuantity={incrementQuantity}
              decrementQuantity={decrementQuantity}
              removeFromCart={removeFromCart}
              clearCart={clearCart}
              calculateTotal={calculateTotal}
              checkout={checkout}
            />
            <ProductDetailModal
              show={showProductDetailModal}
              handleClose={() => setShowProductDetailModal(false)}
              product={selectedProduct}
              addToCart={addToCart}
            />
            {/* Admission Number Modal */}
            <Modal
              show={showAdmissionModal}
              onHide={() => setShowAdmissionModal(false)}
              centered
            >
              <Modal.Header closeButton>
                <Modal.Title>Enter Admission Number</Modal.Title>
              </Modal.Header>
              <Modal.Body>
                <Form.Group>
                  <Form.Label>Admission Number</Form.Label>
                  <Form.Control
                    type="text"
                    value={admissionNumber}
                    onChange={(e) => setAdmissionNumber(e.target.value)}
                    placeholder="Enter your admission number"
                  />
                </Form.Group>
              </Modal.Body>
              <Modal.Footer>
                <Button
                  variant="secondary"
                  onClick={() => setShowAdmissionModal(false)}
                >
                  Cancel
                </Button>
                <Button variant="primary" onClick={handleAdmissionConfirm}>
                  Confirm Payment
                </Button>
              </Modal.Footer>
            </Modal>
            {/* Receipt Modal */}
            <Modal
              show={showReceiptModal}
              onHide={() => setShowReceiptModal(false)}
              centered
            >
              <Modal.Header closeButton>
                <Modal.Title>Payment Successful</Modal.Title>
              </Modal.Header>
              <Modal.Body>
                <p>Your order has been placed successfully!</p>
              </Modal.Body>
              <Modal.Footer>
                <Button
                  variant="primary"
                  onClick={() => setShowReceiptModal(false)}
                >
                  Close
                </Button>
              </Modal.Footer>
            </Modal>
            <Toast
              show={showCheckoutToast}
              delay={3000}
              autohide
              className="position-fixed bottom-0 end-0 m-3"
            >
              <Toast.Body>Checkout successful!</Toast.Body>
            </Toast>
          </>
        )}
        {/* Floating Cart Button */}
        {cart.length > 0 && !showCartModal && (
          <button
            className="floating-cart-btn animate__animated animate__bounceIn"
            onClick={handleFloatingCartClick}
            aria-label="View Cart"
          >
            <FaShoppingCart />
            <span className="floating-cart-count">{cart.length}</span>
          </button>
        )}
      </Container>
      <Footer />
    </div>
  );
};

export default App;
