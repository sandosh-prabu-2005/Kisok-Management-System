// backend/server.js
require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const helmet = require("helmet");
const bodyParser = require("body-parser");

// Serve static files for the React app at /sandosh-prabu-2005
const path = require("path");

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use((req, res, next) => {
  console.log("--- Incoming Request ---");
  console.log("URL:", req.originalUrl);
  console.log("Method:", req.method);
  console.log("Headers:", req.headers);
  next();
});
app.use(helmet());
app.use(cors({ origin: "http://localhost:3000" })); // Removed credentials:true, no cookies needed
app.use(bodyParser.json());
app.use("/sandosh-prabu-2005", express.static(path.join(__dirname, "../build")));

// For any route under /sandosh-prabu-2005, serve index.html (for React Router)
app.get("/sandosh-prabu-2005/*", (req, res) => {
  res.sendFile(path.join(__dirname, "../build", "index.html"));
});

// MongoDB connection
const mongoURI =
  process.env.MONGO_URI ||
  "mongodb+srv://sandy-db:Sandy%402005@sandycluster.xvjen3a.mongodb.net/?authMechanism=SCRAM-SHA-1&authSource=admin";
mongoose
  .connect(mongoURI)
  .then(() => console.log("MongoDB connected"))
  .catch((err) => console.error("MongoDB connection error:", err));

// Schemas
const ProductSchema = new mongoose.Schema({
  name: String,
  price: Number,
  quantity: Number,
  description: String,
  image: String,
});
const UserSchema = new mongoose.Schema({
  admissionNumber: String,
  name: String,
  department: String,
  wallet_balance: Number,
  password: String,
  role: String,
  email: String,
});
const SaleSchema = new mongoose.Schema({
  userId: String,
  userEmail: String,
  items: Array,
  total: Number,
  timestamp: Number,
});

const Product = mongoose.model("Product", ProductSchema);
const User = mongoose.model("User", UserSchema);
const Sale = mongoose.model("Sale", SaleSchema);

// Health check endpoint
app.get("/api/health", (req, res) => res.json({ status: "ok" }));

// API Endpoints
app.get("/api/products", async (req, res) => {
  console.log("/api/products endpoint hit");
  const headerSize = JSON.stringify(req.headers).length;
  if (req.headers.cookie) {
    console.error("Cookie header present:", req.headers.cookie.length, "bytes");
    console.error("Cookie header value:", req.headers.cookie);
  }
  if (headerSize > 8000) { // 8KB is a common limit
    console.error("Request headers too large:", headerSize, "bytes");
    return res.status(431).json({ error: "Request Header Fields Too Large" });
  }
  try {
    const products = await Product.find();
    res.json(products);
  } catch (err) {
    console.error("Error fetching products:", err);
    res.status(500).json({ error: "Error fetching products" });
  }
});

app.get("/api/products/:id", async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).json({ error: "Product not found" });
    res.json(product);
  } catch (err) {
    res.status(500).json({ error: "Error fetching product" });
  }
});

app.post("/api/products/update-quantity", async (req, res) => {
  const { id, quantityChange } = req.body;
  try {
    const product = await Product.findById(id);
    if (!product) return res.status(404).json({ error: "Product not found" });
    product.quantity += quantityChange;
    await product.save();
    res.json({ message: "Quantity updated", newQuantity: product.quantity });
  } catch (err) {
    res.status(500).json({ error: "Error updating quantity" });
  }
});

app.get("/api/users", async (req, res) => {
  try {
    const users = await User.find(
      {},
      "admissionNumber name department wallet_balance role email"
    );
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: "Error fetching users" });
  }
});

app.post("/api/users", async (req, res) => {
  try {
    const user = new User(req.body);
    await user.save();
    res.json({ message: "User added successfully" });
  } catch (err) {
    res.status(500).json({ error: "Error adding user" });
  }
});

// Record a sale (checkout)
app.post("/api/sales", async (req, res) => {
  try {
    const sale = new Sale(req.body);
    await sale.save();
    // Update user's wallet balance by admission number
    await User.updateOne(
      { admissionNumber: req.body.userId },
      { $inc: { wallet_balance: -req.body.total } }
    );
    res.json({ message: "Sale recorded successfully" });
  } catch (err) {
    res.status(500).json({ error: "Error recording sale" });
  }
});

app.get("/api/sales", async (req, res) => {
  try {
    const sales = await Sale.find();
    res.json(sales);
  } catch (err) {
    res.status(500).json({ error: "Error fetching sales" });
  }
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: "Internal server error" });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
